# Telkomsel API by uragiristereo
Written in Python 3.5
### Instalasi

Termux
```sh
$ pkg install python
$ pkg install git
$ pip install requests
$ git clone https://github.com/uragiristereo/telkomsel-api
```

### Indeks
| Channel | Nama file |
| ------ | ------ |
|MyTelkomsel (UX)| ux.py
|MAXStream (VMP)| vmp.py

### Penggunaan
```sh
$ cd tembak-telkomsel
$ python vmp.py
```